To use these sample designs, please copy them to your desktop and uncompress.
